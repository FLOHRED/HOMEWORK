package com.florencia;

public class HolaMundo {
    public static void main(String[] args){
        byte variableA = 3;
        short variableB = 10;
        int variableC = 21;
        long variableD = 23;
        float variableE = 4.4f;
        double variableF =3.4d;
        boolean variable1 = true;
        boolean variable2 = false;
        char variable3 = 'a';
        String variable4 = "Nosotros programamos";

        System.out.println(variableA);
        System.out.println(variableB);
        System.out.println(variableC);
        System.out.println(variableD);
        System.out.println(variableE);
        System.out.println(variableF);
        System.out.println(variable1);
        System.out.println(variable2);
        System.out.println(variable3);
        System.out.println(variable4);
        
    }
}
