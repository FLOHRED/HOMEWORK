public class Coche {
    String modelo;
    int año;
    int puertas;

    public Coche() {

    }

    public Coche(String modelo, int año, int puertas) {
        this.modelo = modelo;
        this.año = año;
        this.puertas = puertas;

    }


    @Override
    public String toString() {
        return "Coche{" +
                "modelo='" + modelo + '\'' +
                ", año=" + año +
                ", puertas=" + puertas +
                '}';
    }
}
