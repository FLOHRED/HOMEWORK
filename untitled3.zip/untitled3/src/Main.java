import java.util.List;

public class Main {

    static CocheCRUD cocheCRUD = new CocheCRUDimple();

    public static void main(String[] args) {

        Coche mazda = new Coche("MMZ",2020,4);
        Coche ford = new Coche("GTX",2021,4);

        cocheCRUD.save(ford);
        cocheCRUD.save(mazda);
        cocheCRUD.findAll();

        List<Coche> empleados = cocheCRUD.findAll();
        System.out.println(empleados);

        cocheCRUD.delete(ford);
        System.out.println(empleados);

    }
}