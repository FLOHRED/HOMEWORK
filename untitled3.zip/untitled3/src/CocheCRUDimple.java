import java.util.ArrayList;
import java.util.List;


public class CocheCRUDimple implements CocheCRUD {
    public List<Coche> coches = new ArrayList<Coche>();

    @Override
    public void save(Coche coche) {
    coches.add(coche);
    }

    @Override
    public List<Coche> findAll() {

        return this.coches;
    }

    @Override
    public void delete(Coche coche) {
        coches.remove(coche);

    }
}
